from pyspark.sql import SparkSession

spark = SparkSession.builder.master("local[*]").getOrCreate()


# df = spark.read.csv('/content/fifa-world-cup.csv',header=True,inferSchema=True)
sparkGroupBy = '''
                              EDITION  YEAR      LOCATION   WINNER  TEAMS  MATCHES  GOALS  AVERAGE_GOALS  AVERAGE_ATTENDANCE
0        2014 FIFA World Cup Brazil ™  2014        Brazil  Germany     32       64    171            2.7               52918
1  2010 FIFA World Cup South Africa ™  2010  South Africa    Spain     32       64    145            2.3               49669
2       2006 FIFA World Cup Germany ™  2006       Germany    Italy     32       64    147            2.3               52491



 from pyspark.sql.types import *
 from pyspark.sql.functions import *
 ######################################################################
 #####spark dataframe group by having and rename group field
 #########################################################################   
 def sparkDFGroupBy(df)   :   
    return (
           #########df.groupBy()            ## group by all string field
           df.groupBy(df.EDITION  , df.LOCATION  , df.WINNER )
           ######sum()                    ## sum all numeric column
           #sum(            "YEAR"    ,            "TEAMS"    ,            "MATCHES"    ,            "GOALS"    ,            "AVERAGE_GOALS"    ,            "AVERAGE_ATTENDANCE"      )

           #######1      .sort(["sum(col1)","sum(col2)"] , ascending=False )
           ###### 2       .orderBy([df.col1.desc(), col("sum(col1)").desc() ])
        .agg(
           sum("YEAR") ,  avg("YEAR") ,
           count("YEAR") , max("YEAR")  , min("YEAR") ,

           sum("TEAMS") ,  avg("TEAMS") ,
           count("TEAMS") , max("TEAMS")  , min("TEAMS") ,

           sum("MATCHES") ,  avg("MATCHES") ,
           count("MATCHES") , max("MATCHES")  , min("MATCHES") ,

           sum("GOALS") ,  avg("GOALS") ,
           count("GOALS") , max("GOALS")  , min("GOALS") ,

           sum("AVERAGE_GOALS") ,  avg("AVERAGE_GOALS") ,
           count("AVERAGE_GOALS") , max("AVERAGE_GOALS")  , min("AVERAGE_GOALS") ,

           sum("AVERAGE_ATTENDANCE") ,  avg("AVERAGE_ATTENDANCE") ,
           count("AVERAGE_ATTENDANCE") , max("AVERAGE_ATTENDANCE")  , min("AVERAGE_ATTENDANCE")  
            )  # can have avg(),max(),min().mean(),count(),pivot(col1)

         #Filter groupby sql having clause

      .where( column( "sum(YEAR)"   ) != 0  ) 
      .where( column( "sum(TEAMS)"   ) != 0  ) 
      .where( column( "sum(MATCHES)"   ) != 0  ) 
      .where( column( "sum(GOALS)"   ) != 0  ) 
      .where( column( "sum(AVERAGE_GOALS)"   ) != 0  ) 
      .where( column( "sum(AVERAGE_ATTENDANCE)"   ) != 0  ) 


         ## rename clause
             .withColumnRenamed( 'sum(YEAR)'               , "Total YEAR") 
    .withColumnRenamed( 'sum(TEAMS)'               , "Total TEAMS") 
    .withColumnRenamed( 'sum(MATCHES)'               , "Total MATCHES") 
    .withColumnRenamed( 'sum(GOALS)'               , "Total GOALS") 
    .withColumnRenamed( 'sum(AVERAGE_GOALS)'               , "Total AVERAGE_GOALS") 
    .withColumnRenamed( 'sum(AVERAGE_ATTENDANCE)'               , "Total AVERAGE_ATTENDANCE") 

    .withColumnRenamed( 'avg(YEAR)'               , "Average YEAR") 
    .withColumnRenamed( 'avg(TEAMS)'               , "Average TEAMS") 
    .withColumnRenamed( 'avg(MATCHES)'               , "Average MATCHES") 
    .withColumnRenamed( 'avg(GOALS)'               , "Average GOALS") 
    .withColumnRenamed( 'avg(AVERAGE_GOALS)'               , "Average AVERAGE_GOALS") 
    .withColumnRenamed( 'avg(AVERAGE_ATTENDANCE)'               , "Average AVERAGE_ATTENDANCE") 

    .withColumnRenamed( 'min(YEAR)'               , "Minimum YEAR") 
    .withColumnRenamed( 'min(TEAMS)'               , "Minimum TEAMS") 
    .withColumnRenamed( 'min(MATCHES)'               , "Minimum MATCHES") 
    .withColumnRenamed( 'min(GOALS)'               , "Minimum GOALS") 
    .withColumnRenamed( 'min(AVERAGE_GOALS)'               , "Minimum AVERAGE_GOALS") 
    .withColumnRenamed( 'min(AVERAGE_ATTENDANCE)'               , "Minimum AVERAGE_ATTENDANCE") 

    .withColumnRenamed( 'max(YEAR)'               , "Maximum YEAR") 
    .withColumnRenamed( 'max(TEAMS)'               , "Maximum TEAMS") 
    .withColumnRenamed( 'max(MATCHES)'               , "Maximum MATCHES") 
    .withColumnRenamed( 'max(GOALS)'               , "Maximum GOALS") 
    .withColumnRenamed( 'max(AVERAGE_GOALS)'               , "Maximum AVERAGE_GOALS") 
    .withColumnRenamed( 'max(AVERAGE_ATTENDANCE)'               , "Maximum AVERAGE_ATTENDANCE") 



         ##  Sorting 
         ##.orderBy([df.continent.desc(), col("Total beer_servings").desc() ])

         )

         '''
mainTemplate = '''

from pyspark.sql.types import * 
from pyspark.sql.functions  import *
from pyspark.sql import SparkSession
spark = SparkSession.builder.master("local[*]").getOrCreate()

def getStruct()  :
                return  (StructType() \n{0}                
                        )
def getsparkDf(df)  :
                return  (df.select (input_file_name().alias('file')  \n{1}                     
                                   )
                        )
def generateSql(df)  : 

   df.createOrReplaceTempView('df')

   dfSql =  spark.sql( \'''select 
                           {2} 
                           input_file_name()        As  File 
                          from     df 
                        \'''
                      )
   spark.catalog.dropTempView('df') 
   return dfSql

if __name__ == '__main__'  :
      schema = getStruct()
      dftest = spark.read.csv('{3}' ,    #/content/fifa-world-cup.csv',
                              schema=schema,
                              sep= ',',
                              header=True
                              )
      # dfout= dftest._jdf.showString(5, 20000, False) 
      # print(dfout)                           
      df1=  getsparkDf(dftest) 
      df1.show(30,4000) 
      dfSql = generateSql(dftest)
      dfSql.show(30,4000)
'''

rddTemplate = '''
import pyspark
from pyspark.sql import SparkSession
from pyspark import *
# sc = SparkContext()
from pyspark import SparkContext

sc = SparkContext.getOrCreate()
from pyspark.sql import SQLContext
sqlContext = SQLContext(sc)

csvString="""
EDITION,YEAR,LOCATION,WINNER,TEAMS,MATCHES,GOALS,AVERAGE_GOALS,AVERAGE_ATTENDANCE
2014 FIFA World Cup Brazil ™,2014,Brazil,Germany,32,64,171,2.7,52918
2010 FIFA World Cup South Africa ™,2010,South Africa,Spain,32,64,145,2.3,49669
"""
def    StringToRddDf(csvString,Seperator=",")  :
        def udfParse(x) :
            x=x.strip()
            if (x!="") :
               print(x)
            return x.split(",") 

        csvString=csvString.strip()
        heading = csvString.split("\n")[0]
        header = heading.strip().split(Seperator)    
        print(header)
#         print(csvString, heading , header)
        rdd = sc.parallelize(csvString.split("\n")).                               \
                filter(lambda x : (x.strip() != "" and  x.find(heading) != 0)).      \
                 map(udfParse)  
        return  rdd,rdd.toDF(header)
rdd,myDf = StringToRddDf(csvString.strip(), ",")   
# df = sqlContext.createDataFrame(rdd,getStruct()) 
schemaInString = myDf._jdf.schema().treeString()
myDf.show()
print(myDf._jdf.schema().treeString())
'''
def getFieldAndType(schema):
    fields = []
    dataTypes = []
    leng = []
    mapColumns = {}
    for aline in schema.split('\n'):
        field = aline.split(':')[0][5:]
        if field != '':
            fields.append(field)
            leng.append(len(field))
            # dataTypes
            type = aline.split(':')[1].split(' (')[0][1:]

            dataTypes.append(type)
    colMaxsize = max(leng) + 5
    for index in range(len(fields)):
        aItem = fields[index]
        dType = dataTypes[index]
        mylist = []
        fieldWithQuotes = '"{0}"'.format(aItem).ljust(colMaxsize)
        mylist.append(fieldWithQuotes)
        # mylist.append('{0}'.format(aItem).ljust(colMaxsize) )
        mylist.append('{0}'.format(aItem).ljust(colMaxsize))
        mylist.append('"{0}"'.format(dType).ljust(12))
        # print(mylist)
        mapColumns[aItem] = mylist
    return mapColumns


def getStructAndDfSql(mapColumns):
    struct = ''
    dfs = ' '
    structSyn = '''from pyspark.sql.types import * \nfrom pyspark.sql.functions  import *
              \ndef getStruct()  :
                return  (StructType()\n'''
    structSyn = ''
    dfSyn = '''def getsparkDf()  :
                return  (df.select (\n{0}                     )
            '''
    dfSyn = ''
    for aItem in mapColumns.keys():
        colName = mapColumns.get(aItem)[0]
        dataType = mapColumns.get(aItem)[2]
        # print(mapColumns.get(aItem)[0]+'|', mapColumns.get(aItem)[1]+'|',mapColumns.get(aItem)[3]+'|')
        struct += '                          .add  ( {0} ,   {1}  ,   True)'.format(colName, dataType) + '\n'
        dfs += '                        ,col  ( {0} )   .alias ( {0}  )  .cast (  {1}  )'.format(colName,
                                                                                                 dataType) + '\n'
    return struct, dfs


#
def getSql(mapColumns):
    sql = '\n'
    for aItem in mapColumns.keys():
        colName = mapColumns.get(aItem)[1]
        sql += '                    {0}  As  {0} ,\n'.format(colName)
    return sql[:-1]


def main(filename='/content/fifa-world-cup.csv'):
    df = spark.read.csv(filename, header=True, inferSchema=True)
    schema = df._jdf.schema().treeString()
    mapColumns = getFieldAndType(schema)
    struct, dfs = getStructAndDfSql(mapColumns)
    sqlStatement = getSql(mapColumns)
    text = '\'\'\'\n{0}\n\'\'\'\n      '.format(df._jdf.showString(4, 20000, False))
    finalText=text+mainTemplate.format(struct, dfs, sqlStatement,filename)
    # /content/fifa-world-cup.csv
    with open('/content/sparkCaseOutput/sqlFromStruct.txt', 'w') as f:
        print(finalText)
        f.write(finalText)
    with open('/content/sparkCaseOutput/sparkGroupBy.txt', 'w') as f:
        f.write(sparkGroupBy)
    with open('/content/sparkCaseOutput/rddSpark.txt', 'w') as f:
        f.write(text+rddTemplate)

    return df


import sys

if __name__ == '__main__':
    if len(sys.argv) <= 3:
        df = main()
    else:
        main(sys.argv[3])