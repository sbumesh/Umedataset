import pandas as pd
def getGreetings(str='Hello From War file') :
    df=pd.read_csv('https://raw.githubusercontent.com/hathix/cs171/master/hw5/data/fifa-world-cup.csv').head(2)
    return str+df.to_csv()

if __name__ == '__main__' :
    test= getGreetings(str='Hello From War file')
    print(test)