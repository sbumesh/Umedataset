from requests_toolbelt.multipart import decoder
from google.cloud import storage
import sys
import pandas as pd
from io import StringIO
import io
import os
import matplotlib.pyplot as plt
# Provide path for service accounts keys for authentication
try :
     storage_client = storage.Client()
except :
    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = r"/GCLoudP/umeshcobalt-broker-356-b877d5657bdd.json"
    storage_client = storage.Client()
outfolder = 'etl_gdp'


def displayFiles(bucket, text, fileName):
    print('inside Function=', bucket)
    blobs = storage_client.list_blobs(bucket)
    for blob in blobs:
        print('\n', 'bucket=', bucket, 'filename=', blob.name, sep='\t')
    bucket = storage_client.get_bucket(outfolder)
    print('umesh', bucket)
    # '''
    # try:
    my_file = bucket.blob(fileName)
    # # create in memory file
    # output = io.StringIO("This is a test \n")
    # # upload from string

    my_file.upload_from_string(data=text, content_type='text/plain')
    writeToFolder(filename=fileName + '.png')
    # output.close()
    # except:
    #         print('exectption')
    # '''


def getDf(bucket12, model_filename):
    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket12)
    print(bucket12, bucket)
    model_filename = model_filename
    blob = bucket.blob(model_filename)
    print(blob)
    blob.download_to_filename('/tmp/temp.csv')
    df = None
    with open('/tmp/temp.csv', 'rb') as f:
        df = pd.read_csv(f)
        print(df)
    return df


def getCountryDf(df, aItem):
    print(aItem)
    query = 'country == "{0}"'.format(str(aItem))
    dfByCountry = df.query(query)  # .to_csv(sep='|',index=False)
    text = dfByCountry.to_csv(index=False)
    return dfByCountry


def writeToFolder(filename='t.png', tmpFile='/tmp/temp.png'):
    bucket = storage_client.get_bucket(outfolder)
    print(bucket)
    blob = bucket.blob(filename)
    blob.upload_from_filename(tmpFile)
    print('umesh', bucket, blob)

    # blob.upload_from_file()


def writeExcelfile():
    import xlsxwriter

    workbook = xlsxwriter.Workbook('/tmp/hello.xlsx')
    worksheet = workbook.add_worksheet()

    worksheet.write('A1', 'Hello world')

    workbook.close()
    writeToFolder(filename='myexcel.xlsx', tmpFile='/tmp/hello.xlsx')

def main(mEvent , mcontext) :
    file= mEvent
    print(event, context)
    bucket = storage_client.bucket(file['bucket'])
    print('Bucket Name :  {}'.format(file['bucket']))
    print('Object Name :  {}'.format(file['name']))
    print('Bucket Object :  {}'.format(bucket))

    blob = bucket.get_blob(file['name'])
    print('Blob Object :  {}'.format(blob))
    df = getDf(file['bucket'], file['name'])

    writer = pd.ExcelWriter("/tmp/gdpAll.xlsx", engine='xlsxwriter')
    workbook = writer.book

    for aItem in pd.unique(df.country):
        dfByCountry = getCountryDf(df, aItem)
        ax = dfByCountry.plot.bar(x='year',
                                  y=['pop'],
                                  xlabel='Year',
                                  ylabel='Population Count',
                                  title=' Year Wise Population for {0} '.format(aItem)
                                  )
        dfByCountry.plot.bar(x='year',
                             y=['gdpPercap'],
                             xlabel='Year',
                             ylabel='gdp Per cap',
                             title=' Year Wise Population for {0} '.format(aItem)
                             )
        plt.savefig('/tmp/temp.png')
        displayFiles(bucket, dfByCountry.to_csv(sep='|', index=False), 'Countries/{0}/{0}.txt'.format(aItem))
        dfByCountry.to_excel(writer, sheet_name=aItem, index=False)
        worksheet = writer.sheets[aItem]

    # df.to_excel(writer, sheet_name='Sheet1' , index = False)
    # workbook  = writer.book
    # worksheet = writer.sheets['Sheet1']
    workbook.close()
    writeToFolder(filename='gdpbyCountry.xlsx', tmpFile="/tmp/gdpAll.xlsx")
    writeExcelfile()
def hello_gcs(event, context):
    file = event
    main(mEvent=event, mcontext=context)


if __name__ == '__main__' :
    event = {'bucket': 'umesh21', 'name': 'gapminder-FiveYearData.csv'}
    context = None
    hello_gcs(event, context)